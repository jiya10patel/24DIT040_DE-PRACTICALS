# System Manifesto — Online Shopping Data Engineering Lifecycle

This document tracks the cross-cutting undercurrents — **Security**, **Privacy**, and **Observability** — across each stage of the data engineering lifecycle for the online shopping platform.

---

## 1. Generation
- **Security:** Validate all user input at the source; sanitize before capture.
- **Privacy:** Do not log raw passwords, card numbers, or other sensitive fields in clickstream events.
- **Observability:** Capture event timestamps and source metadata for traceability.

## 2. Ingestion
- **Security:** Encrypt data in transit (TLS) for all real-time and batch feeds.
- **Privacy:** Mask/redact PII before it enters the pipeline.
- **Observability:** Monitor ingestion lag and failed/dropped events.

## 3. Storage
- **Security:** Encrypt data at rest; enforce role-based access control.
- **Privacy:** Separate PII from transactional data; anonymize where possible.
- **Observability:** Track storage growth and query performance.

## 4. Transformation
- **Security:** Audit and log who triggers/runs ETL jobs.
- **Privacy:** Aggregate or anonymize data before it reaches downstream dashboards.
- **Observability:** Log job success/failure and run data quality checks.

## 5. Serving
- **Security:** Authenticate all dashboard/API access.
- **Privacy:** Enforce role-based data visibility (e.g. a seller sees only their own inventory).
- **Observability:** Monitor usage patterns and response times.

---

*Prepared as part of the Data Engineering Lifecycle lab exercise — Online Shopping System.*
