# Data Engineering Lifecycle — Online Shopping System

## Overview
This repository maps the end-to-end data engineering lifecycle for an enterprise **online shopping (e-commerce) platform**, tracing data across five core stages: **Generation → Ingestion → Storage → Transformation → Serving**.

## Contents
- `data_lifecycle_diagram.svg` / `online_shopping_lifecycle_final.drawio` — architectural data flow diagram
- `MANIFESTO.md` — system manifesto covering security, observability, and data privacy undercurrents

## Lifecycle Stages

| Stage | Description | Examples |
|---|---|---|
| **1. Generation** | Where data originates | Clickstream events, orders, payments, seller/inventory feeds |
| **2. Ingestion** | How data enters the system | Kafka (real-time), batch ETL, REST API, CSV import |
| **3. Storage** | Where data is stored | PostgreSQL (transactional), Data Lake/S3 (raw), Data Warehouse (curated) |
| **4. Transformation** | Processing & cleaning | Spark/Python ETL, sales trend computation, recommendation features |
| **5. Serving** | Final consumption | Dashboards, recommendation engine, CSV/PDF reports |

## Key Questions / Analysis

**1. How do downstream serving needs influence upstream ingestion/storage design?**
Serving requirements (e.g. real-time recommendations, live dashboards) drive whether ingestion must be streaming vs batch, and whether storage needs to support fast queries (warehouse) vs cheap bulk storage (data lake).

**2. Broader data lifecycle vs. technical data engineering lifecycle:**
The broader data lifecycle covers the entire life of data from creation to deletion across an organization (including business use, governance, archival). The technical data engineering lifecycle is the subset an engineer directly builds and operates: ingestion, storage, transformation, and serving pipelines.

**3. How are security & observability enforced at each lifecycle boundary?**
- **Security:** encryption in transit/at rest, role-based access control at each handoff point.
- **Observability:** monitoring, logging, and data quality checks at every stage transition to catch failures or drift early.

## Undercurrents
**Security, Observability, and Data Privacy** apply continuously across all five stages — not as a separate step, but embedded at every transition (see `MANIFESTO.md` for stage-by-stage detail).

## Tools Used
Draw.io, Git, GitHub

---
*Prepared as part of the Data Engineering Lifecycle lab exercise.*
